<?php
  if (isset($_POST["Send"])) {
    echo "testing";
  }
?>