    <!-- Header Section Starts Here -->

        <?php include('header.php') ?>
    
    <!-- Header Section Ends Here -->  


    <!-- Navbar Section Ends Here -->

    <!-- fancy item Search Section Starts Here -->
    <section class="fancy-items-search text-center">
        <div class="container">
            
            <form action="" method="POST">
                <input type="search" name="search" placeholder="Search for Fancy Items.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- Fancy Search Section Ends Here -->




    <!-- Footer Section Starts Here -->

        <?php 

            include('footer.php');
        ?>

    <!-- Footer Section Ends Here -->

</body>
</html>