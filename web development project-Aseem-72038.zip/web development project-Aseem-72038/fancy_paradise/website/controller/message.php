<?php
  $link=mysql_connect()
?>